#include "FogOfWar.h"
#include "j1Scene.h"
#include "p2Log.h"
#include "j1Input.h"
#include "Entity.h"
#include "j1Textures.h"
#include "MainScene.h"
#include "j1Map.h"
#include "GameObject.h"
#include "Player.h"

FogOfWar::FogOfWar()
{

	int size = App->map->data.width*App->map->data.height;
	data = new uint[size];
	
	memset(data, 0, size * sizeof(uint));

	fog_of_war_texture = App->tex->LoadTexture("maps/Fow_meta.png"); 

}

FogOfWar::~FogOfWar()
{

}

bool FogOfWar::AddPlayer(Player* new_entity)
{

	if (new_entity == nullptr)
		return false;

	else if (new_entity->type == entity_name::player)
	{
		player_unit new_player;
		
		new_player.player_pos = App->map->WorldToMap(new_entity->player_go->GetPos().x, new_entity->player_go->GetPos().y);

		// TODO 2 ---- Get the frontier and save it on player_unit (Fill the function or create your own shape!)
		GetEntitiesCircleFrontier(new_player);
		// ----

		new_player.id = new_entity->id;
		new_entity->is_on_fow = true; 
		players_on_fog.push_back(new_player);
	}

	else
	{
		simple_player_unit new_player; 

		new_player.player_pos = App->map->WorldToMap(new_entity->player_go->GetPos().x, new_entity->player_go->GetPos().y); 
		new_player.visible = false; 
		new_player.id = new_entity->id;
		simple_char_on_fog_pos.push_back(new_player);
	}
		

	return true;
}

uint FogOfWar::Get(int x, int y)
{
	return data[(y*App->map->data.width) + x];
}

void FogOfWar::Start()
{
	FillFrontier();

	//Optional Improvements

	//RemoveDimJaggies();
	//RemoveDarkJaggies(); 

	ManageCharacters(); 
}

void FogOfWar::Update(iPoint prev_pos, iPoint next_pos)
{
	// We look for the direction that the player is moving

	// TODO 4 ---- Update the character current position in case they move 

	if(prev_pos.x + 1 == next_pos.x)
		SelectMovingPlayer(prev_pos, "right");

	else if (prev_pos.x - 1 == next_pos.x)
		SelectMovingPlayer(prev_pos, "left");

	else if (prev_pos.y + 1 == next_pos.y)
		SelectMovingPlayer(prev_pos, "down");

	else if (prev_pos.y - 1 == next_pos.y)
		SelectMovingPlayer(prev_pos, "up");

	// ----

	// Optional improvements

	//RemoveDimJaggies(); 
	//RemoveDarkJaggies(); 

	// Todo 6 ---- Manage characters

	ManageCharacters(); 

}

void FogOfWar::CleanUp()
{
	RELEASE(data); 
}

void FogOfWar::GetEntitiesCircleFrontier(player_unit& new_player)
{
	// TODO 2 --- Fill frontier from new_player 


	// --- 

	for (list<iPoint>::iterator it = new_player.frontier.begin(); it != new_player.frontier.end(); it++)
		data[(*it).y * App->map->data.width + (*it).x] = dim_clear;

}

void FogOfWar::GetEntitiesRectangleFrontier(player_unit & player, int with, int height)
{
	


}

uint FogOfWar::RemoveDimJaggies()
{

	 return 0; 
}
//
void FogOfWar::RemoveDarkJaggies()
{

	
	
}


void FogOfWar::SelectMovingPlayer(iPoint prev_pos, const char* direction)
{
	//string direction_str(direction); 

	for (vector<player_unit>::iterator it = players_on_fog.begin(); it != players_on_fog.end(); it++)
	{
		if (it->id == App->entity->curr_entity->id)
		{
				
		}
	
		// If one player is pushing another

		for (vector<player_unit>::iterator it2 = players_on_fog.begin(); it2 != players_on_fog.end(); it2++)
		{
			if (it->player_pos == it2->player_pos && it->id != it2->id)
			{
				MoveArea(*it2, direction);
				break; 
			}
				
		}
	}
	
}

void FogOfWar::GetCurrentPointsFromFrontier(player_unit& player)
{


	for (list<iPoint>::iterator it = player.current_points.begin(); it != player.current_points.end(); it++)
		data[(*it).y * App->map->data.width + (*it).x] = dim_clear;
	
}



void FogOfWar::FillFrontier()
{
	for (vector<player_unit>::iterator it = players_on_fog.begin(); it != players_on_fog.end(); it++)
	{
		// TODO  3 ---- Fill the inner part of the frontier and store it in player_unity
		GetCurrentPointsFromFrontier(*it);
		// ----		
	}			
}

void FogOfWar::MoveArea(player_unit& player_unity, string direction_str)
{
	for (list<iPoint>::iterator it = player_unity.current_points.begin(); it != player_unity.current_points.end(); it++)
		data[(*it).y * App->map->data.width + (*it).x] = dim_middle;

	// TODO 4 -- Move the current points of the player 

	// ----
	

	for (list<iPoint>::iterator it = player_unity.current_points.begin(); it != player_unity.current_points.end(); it++)
	{
		data[(*it).y * App->map->data.width + (*it).x] = dim_clear;
	}

	// Redraw the others in case of overlaping

	for (vector<player_unit>::iterator it = players_on_fog.begin(); it != players_on_fog.end(); it++)
	{
		if (it->id != App->entity->curr_entity->id)
		{
			for (list<iPoint>::iterator it2 = it->current_points.begin(); it2 != it->current_points.end(); it2++)
			{
				data[(*it2).y * App->map->data.width + (*it2).x] = dim_clear;
			}
		}
	}
		
}

SDL_Rect FogOfWar::GetRect(int fow_id)
{
	SDL_Rect rect_ret = { 0, 0, 32, 32 };

	int columns = 13; 

	if(fow_id > 0 && fow_id <= dim_inner_bottom_right)
	{
		rect_ret.y = 0;
		rect_ret.x = 32 * (fow_id - 1); 	
	}
	else if(fow_id > dim_inner_bottom_right && fow_id <= darkd_inner_bottom_right)
	{
		fow_id -= columns; 
		rect_ret.y = 32;
		rect_ret.x = 32 * (fow_id - 1);
	}
	else if (fow_id > darkd_inner_bottom_right && fow_id <= darkc_inner_bottom_right)
	{
		fow_id -= (columns*2);
		rect_ret.y = 32;
		rect_ret.x = 32 * (fow_id - 1);
	}

	return rect_ret;
}

void FogOfWar::DeletePicks(player_unit& player)
{
	int count = 0;

	for (list<iPoint>::iterator it = player.frontier.begin(); it != player.frontier.end(); it++)
	{
		if ((*it) == iPoint(player.player_pos.x, player.player_pos.y + FOW_RADIUM))
			(*it) = iPoint((*it).x, (*it).y - 1); 

		else if ((*it) == iPoint(player.player_pos.x, player.player_pos.y - FOW_RADIUM))
			(*it) = iPoint((*it).x, (*it).y + 1);

		else if ((*it) == iPoint(player.player_pos.x + FOW_RADIUM, player.player_pos.y))
			(*it) = iPoint((*it).x - 1, (*it).y);

		else if ((*it) == iPoint(player.player_pos.x - FOW_RADIUM, player.player_pos.y))
			(*it) = iPoint((*it).x + 1, (*it).y);
	}

}

// TODO 5 ----

void FogOfWar::ManageCharacters()
{
	

}

// ----

bool FogOfWar::IsVisible(iPoint char_pos)
{

	if (Get(char_pos.x, char_pos.y) > dim_middle && Get(char_pos.x, char_pos.y) < darkd_middle)		
		return true;

	if (Get(char_pos.x, char_pos.y) >= darkc_middle && Get(char_pos.x, char_pos.y) < darkc_inner_bottom_right)
		return true; 

	if (Get(char_pos.x, char_pos.y) == dim_clear)
		return true; 

	else
		return false; 

}

bool FogOfWar::IsFrontier(iPoint point, player_unit& player)
{

	for (list<iPoint>::iterator it = player.frontier.begin(); it != player.frontier.end(); it++)
	{
		if (point == *it)
			return true;
	}

	return false;
}









